package com.example.e2;

public class Constants {
    final static int GET_RANDOM_NUMBER = 1;
    final static int GET_A = 2;
    final static int GET_B = 4;
}
